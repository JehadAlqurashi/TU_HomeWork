<?php
$animal = "panda";
$data = file_get_contents(
	'https://api.flickr.com/services/rest/?'
	 	.http_build_query(array(
		"method" => "flickr.photos.search",
		"api_key" => '2217c6fa2ba12fbd94b841f89462d6ec',
		"tags" => $animal,
		"format" => "xmlrpc",
		"per_page" => "8"
	))
);
$simplexml = new SimpleXMLElement($data);
$data_array = $simplexml->params->param->value->children();
$photos = new SimpleXMLElement($data_array->string);
if($photos){
	foreach($photos->photo as $photo){
		echo $photo['title'] . "\n";
		echo '<img src="http://farm' . $photo['farm'] . '.staticflickr.com/'
		. $photo['server'] . '/' . $photo['id'] . '_' . $photo['secret'] .
		'.jpg" height="100px" /><br />' . "\n";

	}
}
?>