<?php
/* Name : Jehad Alqurashi */
/* ID : 439000605 */
require './src/nusoap.php';
$data = [


    [
    "id" => "1",
    "Name" => "PHP for developers",
    "Image" => "<img src='image/php.jpg' width='100px'><br>",
    "price" => "100 SR",
    ] ,
    [
    "id" => "2",
    "Name" => "JAVA for developers",
    "Image" => "<img src='image/java.jpg' width='100px'>",
    "price" => "200 SR",
    ] 



];
function getBookList(){
    global $data;
    $re = "";
    foreach($data as $d){
       $re.="ID:" . $d['id'] . "<br>" ; 
       $re.="Book:" . $d['Name'] . "<br>";
       $re.="Price: " . $d['price'] . "<br>";
       $re.=$d['Image'] ;
       $re.="<hr>" ;
    }
    return $re;

}
function getBookPrice($title){

global $data;
$price = "";
foreach($data as $t){
    if($title == $t['Name']){
        $price = $t['price'];
        $id = $t['id'];
        $title = $t['Name'];
        $img = $t['Image'];
    }
}


if($price == "")
    return "BOOK: <b>" . $title . "</b> does not exist ! <br>";
else
    return "ID: " . $id . "<br>BOOK: <b>" . $title . "</b><br>Price: <b>" . $price . "</b></br>" . $img;

}
$server = new soap_server();
$server->configureWSDL('server', 'urn:server');


$server->register(
    "getBookPrice",
    array("title" => "xsd:string"),
    array("return" => "xsd:string"),
    'urn:server',
    'urn:server#booksServer',
    'rpc',
    'encoded',
    'Get book Price'

);
function countBooks(){
    global $data;
    return "<p>Number of books: </p>" . count($data) . "</p>";

}
$server->register(
    "countBooks",
    array(),
    array("return" => "xsd:string"),
    'urn:server',
    'urn:server#booksServer',
    'rpc',
    'encoded',
    'Count Books'

);
$server->register(
    "getBookList",
    array(),
    array("return" => "xsd:string"),
    'urn:server',
    'urn:server#booksServer',
    'rpc',
    'encoded',
    'getBookList'

);



$server->service(file_get_contents("php://input"));