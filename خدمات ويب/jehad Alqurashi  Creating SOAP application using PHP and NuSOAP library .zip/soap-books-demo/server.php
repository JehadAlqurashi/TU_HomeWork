<?php
/* Name : Jehad Alqurashi */
/* ID : 439000605 */
require './src/nusoap.php';
$data = [
    "PHP for developers" =>"100 SR",
    "JAVA for developers" => "200 SR"


];

$title = "";
function getBookPrice($title){
$price = "";
global $data;

foreach($data as $t => $p){
    if($title == $t){
        $price = $p;
    }
}
if($price == "")
    return "BOOK: <b>" . $title . "</b> does not exist ! <br>";
else
    return "BOOK: <b>" . $title . "</b><br>Price: <b>" . $price . "</b></br>";
}



$server = new soap_server();
$server->configureWSDL('server', 'urn:server');


$server->register(
    "getBookPrice",
    array("title" => "xsd:string"),
    array("return" => "xsd:string"),
    'urn:server',
    'urn:server#booksServer',
    'rpc',
    'encoded',
    'Get book Price'

);
function countBooks(){
    global $data;
    return "<p>Number of books: </p>" . count($data) . "</p>";

}
$server->register(
    "countBooks",
    array(),
    array("return" => "xsd:string"),
    'urn:server',
    'urn:server#booksServer',
    'rpc',
    'encoded',
    'Count Books'

);

$server->service(file_get_contents("php://input"));