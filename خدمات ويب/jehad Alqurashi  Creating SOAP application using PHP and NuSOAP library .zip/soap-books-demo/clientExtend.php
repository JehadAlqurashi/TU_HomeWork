<?php
/* Name : Jehad Alqurashi */
/* ID : 439000605 */
require './src/nusoap.php';
$wsdl = "http://localhost/soap-books-demo/serverExtend.php?wsdl";
$client = new nusoap_client($wsdl,'wsdl');
$err = $client->getError();
if($err){
    echo "<h2>Constructor error</h2>";
    exit();
}
$list = $client->call("getBookList");
echo $list;

if($_POST){
    $book_title = $_POST['title'];

    $price = $client->call('getBookPrice',array('title' => $book_title));
    print_r($price);
    

    $count = $client->call("countBooks");
    echo "<hr>" ;
    print_r($count) . "n";
}
else{
    echo "
        <form method='post'>
            <input type='text' name='title' placeholder='enter book title'>
            <input type='submit'>
        
        </form>
    ";
}

