<?php
/* Name : Jehad Alqurashi */
/* ID : 439000605 */
require './src/nusoap.php';
$wsdl = "http://localhost/soap-books-demo/server.php?wsdl";
$client = new nusoap_client($wsdl,'wsdl');
$err = $client->getError();
if($err){
    echo "<h2>Constructor error</h2>";
    exit();
}
if($_POST){
    $book_title = $_POST['title'];

    $price = $client->call('getBookPrice',array('title' => $book_title));
    print_r($price);
    

    $count = $client->call("countBooks");
    print_r($count) . "n";
}
else{
    echo "
        <form method='post'>
            <input type='text' name='title' placeholder='enter book title'>
            <input type='submit'>
        
        </form>
    
    
    ";
}